import Conexao
import socket
import os
import threading

threadConexao = Conexao.Conexao("T_Conexao")
threadConexao.start()




