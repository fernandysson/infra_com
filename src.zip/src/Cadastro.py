import threading
import socket
import os

class Cadastro(threading.Thread):

	def __init__ (self, threadName, clisock, remote)
